package aplicacao;

import dao.MedicamentoDAO;
import dao.UsuarioDAO;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Scanner;
import modelo.Medicamento;
import modelo.Usuario;

public class Main {

    private static final Scanner teclado = new Scanner(System.in);
    private static final UsuarioDAO usuarioDAO = new UsuarioDAO();
    private static final MedicamentoDAO medicamentoDAO = new MedicamentoDAO();

    public static void main(String[] args) {
        System.out.println("=== MedRoutine - sua rotina, sob controle ===");

        boolean sair = false;
        while (!sair) {
            System.out.println("\n--- INICIO ---");
            System.out.println("1 - Entrar");
            System.out.println("2 - Cadastrar");
            System.out.println("0 - Sair");
            int opcao = lerInteiro("Escolha: ");

            if (opcao == 1) {
                Usuario usuario = telaLogin();
                if (usuario != null) {
                    menuPrincipal(usuario);
                }
            } else if (opcao == 2) {
                telaCadastro();
            } else if (opcao == 0) {
                sair = true;
            } else {
                System.out.println("Opcao invalida.");
            }
        }
        System.out.println("Ate logo!");
    }

    private static Usuario telaLogin() {
        System.out.println("\n--- LOGIN ---");
        String email = lerTexto("E-mail: ");
        String senha = lerTexto("Senha: ");

        if (email.isEmpty() || senha.isEmpty()) {
            System.out.println("Informe e-mail e senha.");
            return null;
        }

        Usuario usuario = usuarioDAO.autenticar(email, senha);
        if (usuario == null) {
            System.out.println("E-mail ou senha incorretos.");
        }
        return usuario;
    }

    private static void telaCadastro() {
        System.out.println("\n--- CADASTRO ---");
        String nome = lerTexto("Nome: ");
        String email = lerTexto("E-mail: ");
        String senha = lerTexto("Senha (minimo 6 caracteres): ");

        Usuario novo = new Usuario(nome, email, senha);
        String erro = novo.validar();
        if (erro != null) {
            System.out.println("Erro: " + erro);
            return;
        }

        if (usuarioDAO.inserir(novo)) {
            System.out.println("Conta criada com sucesso! Agora e so entrar.");
        }
    }

    private static void menuPrincipal(Usuario usuario) {
        System.out.println("\n" + saudacao() + ", " + usuario.getPrimeiroNome() + "!");

        boolean sair = false;
        while (!sair) {
            System.out.println("\n--- MENU ---");
            System.out.println("1 - Verificar medicamentos");
            System.out.println("2 - Adicionar medicamento");
            System.out.println("0 - Sair da conta");
            int opcao = lerInteiro("Escolha: ");

            if (opcao == 1) {
                telaMedicamentos(usuario);
            } else if (opcao == 2) {
                telaAdicionarMedicamento(usuario);
            } else if (opcao == 0) {
                sair = true;
            } else {
                System.out.println("Opcao invalida.");
            }
        }
    }

    private static String saudacao() {
        int hora = LocalTime.now().getHour();
        if (hora < 12) {
            return "Bom dia";
        } else if (hora < 18) {
            return "Boa tarde";
        }
        return "Boa noite";
    }

    private static void telaMedicamentos(Usuario usuario) {
        System.out.println("\n--- MEUS MEDICAMENTOS ---");
        ArrayList<Medicamento> lista = medicamentoDAO.listarPorUsuario(usuario.getId());

        if (lista.isEmpty()) {
            System.out.println("Nenhum medicamento cadastrado.");
            return;
        }

        int baixos = 0;
        for (Medicamento m : lista) {
            System.out.println("\n" + m.getNome() + " " + m.getDosagem());
            System.out.println("  Dose:     " + m.getDescricaoDose());
            System.out.println("  Horarios: " + m.getHorariosTexto());
            System.out.println("  Estoque:  " + m.getEstoqueAtual() + " de " + m.getEstoqueTotal()
                    + " " + m.getUnidade() + "s (" + m.getPercentualEstoque() + "%)");
            System.out.println("  Duracao:  cerca de " + m.getDiasRestantes() + " dias");
            if (m.isEstoqueBaixo()) {
                System.out.println("  *** ATENCAO: ESTOQUE BAIXO ***");
                baixos++;
            }
        }

        System.out.println("\nTotal: " + lista.size() + " medicamento(s), "
                + baixos + " com estoque baixo.");
    }

    private static void telaAdicionarMedicamento(Usuario usuario) {
        System.out.println("\n--- ADICIONAR MEDICAMENTO ---");
        String nome = lerTexto("Nome (ex.: Losartana): ");
        String dosagem = lerTexto("Dosagem (ex.: 50 mg): ");
        String unidade = lerTexto("Unidade (ex.: comprimido ou capsula): ");
        int qtdPorDose = lerInteiro("Quantidade por dose: ");
        int estoqueAtual = lerInteiro("Quantidade em estoque agora: ");
        int estoqueTotal = lerInteiro("Quantidade total da embalagem: ");
        String horariosTexto = lerTexto("Horarios separados por virgula, formato HH:mm (ex.: 08:00,20:00): ");

        Medicamento medicamento = new Medicamento(usuario.getId(), nome, dosagem, unidade,
                qtdPorDose, estoqueAtual, estoqueTotal);

        String erro = medicamento.validar();
        if (erro != null) {
            System.out.println("Erro: " + erro);
            return;
        }

        if (horariosTexto.isEmpty()) {
            System.out.println("Erro: informe pelo menos um horario.");
            return;
        }

        ArrayList<LocalTime> horarios = new ArrayList<>();
        String[] partes = horariosTexto.split(",");
        for (String parte : partes) {
            try {
                horarios.add(LocalTime.parse(parte.trim()));
            } catch (DateTimeParseException e) {
                System.out.println("Erro: horario invalido \"" + parte.trim() + "\". Use o formato HH:mm.");
                return;
            }
        }

        if (medicamentoDAO.cadastrar(medicamento, horarios)) {
            System.out.println("Medicamento cadastrado com sucesso!");
        }
    }

    private static String lerTexto(String mensagem) {
        System.out.print(mensagem);
        if (!teclado.hasNextLine()) {
            System.exit(0); // entrada encerrada
        }
        return teclado.nextLine().trim();
    }

    private static int lerInteiro(String mensagem) {
        try {
            return Integer.parseInt(lerTexto(mensagem));
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
