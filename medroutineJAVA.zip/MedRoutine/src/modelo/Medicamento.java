package modelo;

import java.time.LocalTime;
import java.util.ArrayList;

public class Medicamento {

    private int id;
    private int idUsuario;
    private String nome;
    private String dosagem;
    private String unidade;
    private int quantidadePorDose;
    private int estoqueAtual;
    private int estoqueTotal;
    private ArrayList<LocalTime> horarios = new ArrayList<>();

    public Medicamento(int id, int idUsuario, String nome, String dosagem, String unidade,
                       int quantidadePorDose, int estoqueAtual, int estoqueTotal) {
        this.id = id;
        this.idUsuario = idUsuario;
        this.nome = nome;
        this.dosagem = dosagem;
        this.unidade = unidade;
        this.quantidadePorDose = quantidadePorDose;
        this.estoqueAtual = estoqueAtual;
        this.estoqueTotal = estoqueTotal;
    }

    public Medicamento(int idUsuario, String nome, String dosagem, String unidade,
                       int quantidadePorDose, int estoqueAtual, int estoqueTotal) {
        this(0, idUsuario, nome, dosagem, unidade, quantidadePorDose, estoqueAtual, estoqueTotal);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public String getNome() {
        return nome;
    }

    public String getDosagem() {
        return dosagem;
    }

    public String getUnidade() {
        return unidade;
    }

    public int getQuantidadePorDose() {
        return quantidadePorDose;
    }

    public int getEstoqueAtual() {
        return estoqueAtual;
    }

    public int getEstoqueTotal() {
        return estoqueTotal;
    }

    public ArrayList<LocalTime> getHorarios() {
        return horarios;
    }

    public void setHorarios(ArrayList<LocalTime> horarios) {
        this.horarios = horarios;
    }

    // Horários em texto: "08:00, 20:00"
    public String getHorariosTexto() {
        if (horarios.isEmpty()) {
            return "-";
        }
        String texto = "";
        for (int i = 0; i < horarios.size(); i++) {
            if (i > 0) {
                texto = texto + ", ";
            }
            texto = texto + horarios.get(i).toString();
        }
        return texto;
    }

    public String getDescricaoDose() {
        if (quantidadePorDose > 1) {
            return quantidadePorDose + " " + unidade + "s";
        }
        return quantidadePorDose + " " + unidade;
    }

    public int getPercentualEstoque() {
        if (estoqueTotal <= 0) {
            return 0;
        }
        return estoqueAtual * 100 / estoqueTotal;
    }

    public boolean isEstoqueBaixo() {
        return getPercentualEstoque() <= 20;
    }

    public int getDiasRestantes() {
        int consumoDiario = quantidadePorDose * horarios.size();
        if (consumoDiario <= 0) {
            return 0;
        }
        return estoqueAtual / consumoDiario;
    }

    public String validar() {
        if (nome == null || nome.trim().isEmpty()) {
            return "O nome do medicamento e obrigatorio.";
        }
        if (dosagem == null || dosagem.trim().isEmpty()) {
            return "A dosagem e obrigatoria (ex.: 50 mg).";
        }
        if (unidade == null || unidade.trim().isEmpty()) {
            return "A unidade e obrigatoria (ex.: comprimido).";
        }
        if (quantidadePorDose <= 0) {
            return "A quantidade por dose deve ser maior que zero.";
        }
        if (estoqueTotal <= 0) {
            return "O estoque total deve ser maior que zero.";
        }
        if (estoqueAtual < 0 || estoqueAtual > estoqueTotal) {
            return "O estoque atual deve estar entre 0 e o estoque total.";
        }
        return null;
    }
}
