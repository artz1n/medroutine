package modelo;

public class Usuario {

    private int id;
    private String nome;
    private String email;
    private String senha;

    public Usuario(int id, String nome, String email, String senha) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
    }

    public Usuario(String nome, String email, String senha) {
        this(0, nome, email, senha);
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public String getSenha() {
        return senha;
    }

    public String getPrimeiroNome() {
        return nome.trim().split(" ")[0];
    }

    public String validar() {
        if (nome == null || nome.trim().isEmpty()) {
            return "O nome e obrigatorio.";
        }
        if (email == null || !email.contains("@")) {
            return "Informe um e-mail valido.";
        }
        if (senha == null || senha.length() < 6) {
            return "A senha deve ter pelo menos 6 caracteres.";
        }
        return null;
    }
}
