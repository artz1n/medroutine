package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.time.LocalTime;
import java.util.ArrayList;
import modelo.Medicamento;


public class MedicamentoDAO {

    public boolean cadastrar(Medicamento m, ArrayList<LocalTime> horarios) {
        String sqlMed = "INSERT INTO medicamento (id_usuario, nome, dosagem, unidade, "
                + "quantidade_por_dose, estoque_atual, estoque_total) VALUES (?, ?, ?, ?, ?, ?, ?)";
        String sqlHorario = "INSERT INTO horario (id_medicamento, hora) VALUES (?, ?)";

        try (Connection con = ConexaoMySQL.getConexao()) {
            con.setAutoCommit(false); 

            try {
                int idGerado;

                try (PreparedStatement ps = con.prepareStatement(sqlMed, Statement.RETURN_GENERATED_KEYS)) {
                    ps.setInt(1, m.getIdUsuario());
                    ps.setString(2, m.getNome());
                    ps.setString(3, m.getDosagem());
                    ps.setString(4, m.getUnidade());
                    ps.setInt(5, m.getQuantidadePorDose());
                    ps.setInt(6, m.getEstoqueAtual());
                    ps.setInt(7, m.getEstoqueTotal());
                    ps.executeUpdate();

                    try (ResultSet rs = ps.getGeneratedKeys()) {
                        if (!rs.next()) {
                            throw new SQLException("Nao foi possivel obter o id do medicamento.");
                        }
                        idGerado = rs.getInt(1);
                    }
                }

                try (PreparedStatement ps2 = con.prepareStatement(sqlHorario)) {
                    for (LocalTime hora : horarios) {
                        ps2.setInt(1, idGerado);
                        ps2.setTime(2, Time.valueOf(hora));
                        ps2.executeUpdate();
                    }
                }

                con.commit();
                m.setId(idGerado);
                return true;

            } catch (SQLException e) {
                con.rollback(); 
                throw e;
            }

        } catch (SQLException e) {
            System.out.println("Erro ao cadastrar medicamento: " + e.getMessage());
            return false;
        }
    }

    public ArrayList<Medicamento> listarPorUsuario(int idUsuario) {
        String sql = "SELECT id_medicamento, id_usuario, nome, dosagem, unidade, "
                + "quantidade_por_dose, estoque_atual, estoque_total "
                + "FROM medicamento WHERE id_usuario = ? ORDER BY nome";

        ArrayList<Medicamento> lista = new ArrayList<>();

        try (Connection con = ConexaoMySQL.getConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idUsuario);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new Medicamento(
                            rs.getInt("id_medicamento"),
                            rs.getInt("id_usuario"),
                            rs.getString("nome"),
                            rs.getString("dosagem"),
                            rs.getString("unidade"),
                            rs.getInt("quantidade_por_dose"),
                            rs.getInt("estoque_atual"),
                            rs.getInt("estoque_total")));
                }
            }

        } catch (SQLException e) {
            System.out.println("Erro ao listar medicamentos: " + e.getMessage());
        }

        for (Medicamento m : lista) {
            m.setHorarios(listarHorarios(m.getId()));
        }
        return lista;
    }

    private ArrayList<LocalTime> listarHorarios(int idMedicamento) {
        String sql = "SELECT hora FROM horario WHERE id_medicamento = ? ORDER BY hora";
        ArrayList<LocalTime> horarios = new ArrayList<>();

        try (Connection con = ConexaoMySQL.getConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idMedicamento);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    horarios.add(rs.getTime("hora").toLocalTime());
                }
            }

        } catch (SQLException e) {
            System.out.println("Erro ao listar horarios: " + e.getMessage());
        }
        return horarios;
    }
}
