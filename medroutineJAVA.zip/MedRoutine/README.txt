MEDROUTINE (versão terminal) - COMO RODAR

1) BANCO: no MySQL Workbench, execute o arquivo medroutine.sql (ou sql/medroutine.sql).
2) NETBEANS: File > Open Project > pasta MedRoutine.
3) DRIVER: botão direito em Libraries > Add Library... > "MySQL JDBC Driver".
   (ou Add JAR/Folder com o mysql-connector-j)
4) SENHA: em src/dao/ConexaoMySQL.java troque COLOQUE_SUA_SENHA_AQUI pela senha
   do seu MySQL (a do root, a mesma do Workbench).
5) Botão direito no projeto > Clean, depois F6. O programa roda na aba "Output" do NetBeans.

Login de teste: marina@exemplo.com / 123456   (ou crie sua conta em "2 - Cadastrar")

ESTRUTURA
   modelo/    Usuario, Medicamento
   dao/       ConexaoMySQL, UsuarioDAO, MedicamentoDAO
   aplicacao/ Main (login, cadastro, verificar e adicionar medicamentos)

SE DER ERRO
   "No suitable driver" = falta o passo 3.   "Access denied" = senha errada no passo 4.
   "Unknown database" = falta o passo 1.
